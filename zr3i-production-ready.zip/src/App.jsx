import React, { useState, useEffect } from "react";
import { Helmet } from "react-helmet";

const longEnglish = `Zr3i is a pioneering carbon farming and sequestration platform serving the Middle East & Africa.
We work with farmers, cooperatives, agribusinesses, NGOs and governments to measure, increase and monetize soil carbon.
Our integrated platform combines satellite remote sensing, in-field soil diagnostics, AI-driven analytics and MRV-ready reporting
to transform agricultural land into climate assets. Farmers receive tailored agronomic advice, regenerative practice plans,
and access to verified carbon credit pathways through our marketplace.`;

const longArabic = `زرعي هي منصة رائدة للزراعة الكربونية واحتجاز الكربون لخدمة الشرق الأوسط وأفريقيا.
نعمل مع المزارعين والتعاونيات والشركات الزراعية والمنظمات والحكومات لقياس وزيادة وتحقيق دخل من كربون التربة.
تدمج منصتنا صور الأقمار الصناعية، تشخيصات التربة الميدانية، تحليلات بالذكاء الاصطناعي وتقارير جاهزة للاعتماد
لتحويل الأراضي الزراعية إلى أصول مناخية. يحصل المزارعون على إرشاد زراعي مخصص وخطط ممارسات تجديدية
ووصول إلى مسارات بيع أرصدة كربون معتمدة عبر السوق.`;

export default function App(){
  const [lang, setLang] = useState('en');
  const isAr = lang === 'ar';
  useEffect(()=>{
    document.documentElement.lang = isAr ? 'ar' : 'en';
    document.title = isAr ? 'زرعي — إحنا بنزرع كربون' : 'Zr3i — We Grow Carbon';
  },[isAr]);

  const jsonLd = {
    "@context":"https://schema.org",
    "@type":"Organization",
    "name": "Zr3i",
    "alternateName":"زرعي",
    "url":"https://zr3i.com",
    "logo":"https://zr3i.com/zr3i-logo-en.svg",
    "description": isAr ? longArabic : longEnglish,
    "sameAs":[ "https://twitter.com/zr3i", "https://www.linkedin.com/company/zr3i" ]
  };

  const t = (en, ar) => isAr ? ar : en;

  return (
    <div className={isAr ? 'rtl font-sans' : 'ltr font-sans'}>
      <Helmet>
        <meta charSet="utf-8" />
        <title>{isAr ? 'زرعي — إحنا بنزرع كربون' : 'Zr3i — We Grow Carbon'}</title>
        <meta name="description" content={isAr ? longArabic : longEnglish} />
        <meta name="keywords" content={isAr ? 'الزراعة الكربونية, احتجاز الكربون, زرعي, أرصدة الكربون' : 'carbon farming, soil carbon, carbon credits, zr3i, MEA'} />
        <script type="application/ld+json">{JSON.stringify(jsonLd)}</script>
        <meta property="og:title" content={isAr ? 'زرعي — إحنا بنزرع كربون' : 'Zr3i — We Grow Carbon'} />
        <meta property="og:description" content={isAr ? longArabic : longEnglish} />
        <meta property="og:image" content="/public-og.png" />
      </Helmet>

      <header className="bg-white shadow p-4">
        <div className="max-w-6xl mx-auto flex justify-between items-center">
          <div className="flex items-center gap-3">
            <img src="/zr3i-logo-en.svg" alt="Zr3i" className="h-12" />
            <div>
              <div className="font-bold">{t('Zr3i','زرعي')}</div>
              <div className="text-xs text-gray-500">{t('We Grow Carbon','إحنا بنزرع كربون')}</div>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <button onClick={()=>setLang(isAr?'en':'ar')} className="px-3 py-1 border rounded">{isAr?'EN':'AR'}</button>
            <a href="#contact" className="bg-green-600 text-white px-3 py-2 rounded">{t('Get Started','ابدأ الآن')}</a>
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto p-6">
        <section className="grid lg:grid-cols-2 gap-8 items-center">
          <div>
            <h1 className="text-4xl font-extrabold">{t('Zr3i — Carbon Farming Platform for MEA','زرعي — منصة الزراعة الكربونية للمنطقة')}</h1>
            <p className="mt-4 text-gray-700 whitespace-pre-line">{isAr ? longArabic : longEnglish}</p>
            <div className="mt-6 flex gap-3">
              <a href="#carbon" className="px-4 py-2 bg-blue-600 text-white rounded">{t('Start Carbon Journey','ابدأ رحلة الكربون')}</a>
              <a href="#resources" className="px-4 py-2 border rounded">{t('Learn More','اعرف أكثر')}</a>
            </div>
          </div>
          <div>
            <img src="/public-og.png" alt="Carbon farming illustration" className="w-full rounded shadow" />
          </div>
        </section>

        <section id="carbon" className="mt-12 bg-white p-6 rounded shadow">
          <h2 className="font-bold text-2xl">{t('How Zr3i Works','كيف تعمل زرعي')}</h2>
          <ol className="mt-4 list-decimal list-inside space-y-2 text-gray-700">
            <li>{t('Map your fields and monitor with satellite imagery and sensors.','ارسم حقولك وراقبها عبر صور الأقمار وأجهزة الاستشعار.')}</li>
            <li>{t('Apply regenerative practices and track soil organic carbon (SOC).','طبق ممارسات تجديدية وتابع الكربون العضوي في التربة.')}</li>
            <li>{t('Verify, certify and monetize carbon credits via our marketplace.','اعتمد واربح من أرصدة الكربون عبر سوقنا.')}</li>
          </ol>
        </section>

        <section id="services" className="mt-8 grid md:grid-cols-3 gap-4">
          <div className="bg-white p-4 rounded shadow">
            <h3 className="font-semibold">{t('Carbon Mapping & Analytics','رسم الخرائط وتحليلات الكربون')}</h3>
            <p className="text-sm text-gray-600 mt-2">{t('Field mapping, SOC estimates and vegetation indices.','رسم حدود الحقول، تقديرات كربون التربة ومؤشرات النبات.')}</p>
          </div>
          <div className="bg-white p-4 rounded shadow">
            <h3 className="font-semibold">{t('Soil Health Diagnostics','تشخيص صحة التربة')}</h3>
            <p className="text-sm text-gray-600 mt-2">{t('Lab integration and AI diagnostics.','دمج نتائج المختبر وتشخيص بالذكاء الاصطناعي.')}</p>
          </div>
          <div className="bg-white p-4 rounded shadow">
            <h3 className="font-semibold">{t('Certification & Marketplace','الاعتماد والسوق')}</h3>
            <p className="text-sm text-gray-600 mt-2">{t('MRV, audit-ready docs and buyer linkages.','MRV، توثيق جاهز للتدقيق وروابط مع المشترين.')}</p>
          </div>
        </section>

        <section id="resources" className="mt-12">
          <h2 className="font-bold text-2xl">{t('Resources & Knowledge Center','مركز المعرفة والموارد')}</h2>
          <div className="mt-4 grid md:grid-cols-3 gap-4">
            <article className="bg-white p-4 rounded shadow">
              <h4 className="font-semibold">{t('How Soil Carbon Changes Everything','كيف يغيّر الكربون في التربة كل شيء')}</h4>
              <p className="text-sm text-gray-600 mt-2">{t('A long-read covering the science and practice of soil carbon sequestration.','مقال تفصيلي عن العلم وممارسات احتجاز الكربون في التربة.')}</p>
            </article>
            <article className="bg-white p-4 rounded shadow">
              <h4 className="font-semibold">{t('MRV Best Practices','أفضل ممارسات MRV')}</h4>
              <p className="text-sm text-gray-600 mt-2">{t('Technical guidance for monitoring, reporting and verification adapted to smallholder contexts.','إرشادات فنية للمراقبة والتقارير والاعتماد تتوافق مع سياقات المزارعين الصغار.')}</p>
            </article>
            <article className="bg-white p-4 rounded shadow">
              <h4 className="font-semibold">{t('Carbon Farming in Egypt','الزراعة الكربونية في مصر')}</h4>
              <p className="text-sm text-gray-600 mt-2">{t('Case study and practical implementation guide.','دراسة حالة ودليل تنفيذ عملي.')}</p>
            </article>
          </div>
        </section>

        <section id="contact" className="mt-12 bg-white p-6 rounded shadow">
          <h2 className="font-bold text-2xl">{t('Contact Us','تواصل معنا')}</h2>
          <p className="text-gray-600 mt-2">{t('Email us at info@zr3i.com or use the contact form below.','راسلنا عبر info@zr3i.com أو استخدم نموذج الاتصال أدناه.')}</p>
          <form className="mt-4 grid gap-3">
            <input placeholder={t('Full name','الاسم الكامل')} className="border p-2 rounded" />
            <input placeholder={t('Email','البريد الإلكتروني')} className="border p-2 rounded" />
            <input placeholder={t('Organization (optional)','الجهة (اختياري)')} className="border p-2 rounded" />
            <textarea placeholder={t('Message','الرسالة')} className="border p-2 rounded h-28" />
            <div className="flex gap-3">
              <button className="bg-green-600 text-white px-4 py-2 rounded">{t('Send Message','أرسل')}</button>
              <a href="mailto:info@zr3i.com" className="px-4 py-2 border rounded">info@zr3i.com</a>
            </div>
          </form>
        </section>

      </main>

      <footer className="bg-gray-50 mt-12 py-6">
        <div className="max-w-6xl mx-auto text-center text-sm text-gray-600">
          © {new Date().getFullYear()} Zr3i — {isAr ? 'جميع الحقوق محفوظة.' : 'All rights reserved.'}
        </div>
      </footer>
    </div>
  );
}